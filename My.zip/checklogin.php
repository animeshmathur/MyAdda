<?php
include("mysqlconnect.php");
$uid=$_POST['my_id'];
$pwd=$_POST['my_pwd'];
$res=mysql_query("SELECT * FROM register WHERE uid='".$uid."' AND pwd='".$pwd."'");
	if(mysql_num_rows($res)==1)
	
	{	
		session_start();
		$_SESSION['uid']=$uid;
		header("location:myhome.php");
		//echo "Login Successful!!!!".$res;
	}
	
	else
	{
		//echo "Login Unsuccessful";
		header("location:index.php?msg=1");
	}
mysql_close($con);
?>