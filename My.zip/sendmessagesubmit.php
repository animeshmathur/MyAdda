<?php 
include("session.php");
include("mysqlconnect.php");
?>
<html>
<head>
<title>PROFILE</title>
<?php include("head.php"); ?>
</head>
<body>
<?php
include("mainlinks.php");
$msgto=$_REQUEST['msgto'];
$msg=$_REQUEST['msgtext'];
$t=time();
$res=mysql_query("select * from autogen");
if($row=mysql_fetch_array($res))
{
	$q="insert into messages values('".$uid."','".$msgto."','".$msg."','".date("D d-F-Y",$t)."','".$row['msgid']."')";
	//echo $q;
	$res1=mysql_query($q);
	if($res1)
	{
		$res2=mysql_query("update autogen set msgid=msgid+1");
	}
}
?>
Message Sent....!

</body>
</html>