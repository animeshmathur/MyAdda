<?php
include("session.php");
include("mysqlconnect.php");
$friend=$_REQUEST['friend'];
?>
<html>
<head>
<?php include("head.php");?>
<title>My Adda : CHAT</title>
<script>
$(document).ready(getChatText);

$(window).unload(function() {
//alert('Handler for .unload() called.');
});

function getChatText()
{
$(document).ready(
function()
{
$.post("chattextwindow.php","friend=<?php echo $friend?>",
function(data,status)
{
//alert(data);
$("#chat_text").append(data);
if(data!="")
{
$("#chat_text_window").scrollTop($("#chat_text_window").height());
}
getChatText();
}
);
}
);
}

function postChatText()
{
$(document).ready(
function()
{
my_txt=document.getElementById('my_text').value;
if(my_txt=="")
{return false;}
else
{
my_txt=my_txt.replace(":)","<img src=images/smilies/smile.png class=smilie>");
my_txt=my_txt.replace(":(","<img src=images/smilies/sad.png class=smilie>");
my_txt=my_txt.replace(":P","<img src=images/smilies/tease.png class=smilie>");
my_txt=my_txt.replace(":D","<img src=images/smilies/big-smile.png class=smilie>");
$("#chat_text").append("<tr><td><i><b><?php echo $uid;?>: </b></i></td><td><i>"+my_txt+"</i></td></tr>");
$("#chat_text_window").scrollTop($("#chat_text_window").height());
document.getElementById('my_text').value="";
$.post("chatsubmit.php","friend=<?php echo $friend?>&txt="+my_txt);}
}
);
}
</script>
<style>
.smilie
{height:15px;width:15px;}
</style>
</head>
<body onUnload="cleanUp();">
<div style="height:100%;width:100%;">
<center>
<div id="chat_text_window" style="height:255;width:480;border:thin #666666 groove;border-radius:15px;padding:5px 5px;background-color:#FFFFFF;overflow:scroll;">
<table id="chat_text" style="float:left;"></table>
</div>
<div id="text_to_send">
<form onSubmit="return false" autocomplete="off">
<table>
<tr><td><input type="text" autocomplete="off" id="my_text" name="txt" style="height:24;width:400"></td><td><button onClick="postChatText()" style="width:80;">Send</button></td></tr>
</table>
</form>
</div>
</center>
</div>
</body>
</html>