<?php
include("session.php");
include("mysqlconnect.php");
?>
<!Doctype html>
<html>
<head>
<meta http-equiv="refresh" content="30">
<?php
include("head.php");
?>
<title>My Adda : CHAT</title>
<script>
var opened_win=new Array();
function popitup(url,id) 
{
//alert("chk");
if(!opened_win[id]||opened_win[id].closed) 
{
	opened_win[id]=window.open(url,'chatwindow'+id,'height=300,width=500');
	if (window.focus) {opened_win[id].focus()}
	return false;
}
else
{
	opened_win[id].focus();
}
}
</script>
</head>
<body>
<div id="chat">
<?php
if(!mysql_num_rows(mysql_query("select * from onlineuser where uid='".$uid."'")))
{
	$res1=mysql_query("insert into onlineuser values('".$uid."')");
}
$count=0;
$res2=mysql_query("select distinct reqto,reqfrom from friends where reqfrom='".$uid."' and status='accepted' or reqto='".$uid."' and status='accepted'");
if(mysql_num_rows($res2))
{
	while($row2=mysql_fetch_array($res2))
	{
		if($uid==$row2['reqfrom'])
		{
			$res=mysql_query("select * from onlineuser where uid='".$row2['reqto']."'");
		}
		else
		{
			$res=mysql_query("select * from onlineuser where uid='".$row2['reqfrom']."'");
		}
		if(mysql_num_rows($res))	
		{
			if($count==0)
			echo "<span style=\"font-size:20px\"><i>:: ...Online Friends... ::</i></span><br><br>";
			echo "<table width=100% cellpadding=10 style=\"background-color:#E5E5E5;color:#4D4C4C;text-align:center;font-size:14px;\">";
			while($row=mysql_fetch_array($res))
			{
				$res1=mysql_query("select uname,dp from register where uid='".$row['uid']."'");
				while($row1=mysql_fetch_array($res1))
				{
					echo "<tr><td><img src=green_bullet.jpg style=\"border-radius:20px;\"></td><td><img src=upload/".$row1['dp']." width=60></td><td>".$row1['uname']."</td><td>";
					?>
                    <button onClick="return popitup('chatwindow.php?friend=<?php echo $row['uid'];?>','<?php echo $row['uid'];?>');" style="color:#0066CC">Chat Now</button></td></tr>
                    <?php
					$count++;
				}
			}
			echo "</table>";
		}
	}
	if($count==0)
	{
		echo "<br><br><br><br><font color=green style=\"font-size:26px;\">* No Friend Is Online Now *</font>";
	}
}
else
{
	echo "<font color=green>* No Friend Available *</font>";
}
echo "<script>";
$res2=mysql_query("select txtfrom from chat where txtto='".$uid."' and txt_status='0' group by txtfrom");
while($row2=mysql_fetch_array($res2))
{
	echo "popitup('chatwindow.php?friend=".$row2['txtfrom']."','".$row2['txtfrom']."');";
}
echo "</script>";
?>
</div>
</body>
</html>