<?php
include("session.php");
include("head.php");
?>
<html>
<head><title>Create Profile</title></head>
<body>
<center>
<form action="createprofilesubmit.php">
<table>
<caption><h1><i>My Profile</i></h1></caption>
<tr><td>My Nick Name: </td><td><input type="text" name="nicknm" /></td></tr>
<tr><td>About Me: </td><td><textarea name="myinfo" columns="100" rows="4"></textarea></td></tr>
<tr><td>Age: </td><td><input type="text" name="age" /></td></tr>
<tr><td>Relationship Status: </td><td><input type="radio" name="relstatus" value="Single" />Single <input type="radio" name="relstatus" value="Married" />Married <input type="radio" name="relstatus" value="Commited" />Commited</td></tr>
<tr>
<td>Hobbies: </td>
<td>
<textarea name="hobbies"></textarea>
<?php 
//<input type="checkbox" name="h1" value="Music">Music <input type="checkbox" name="h2" value="Movies">Movies <input type="checkbox" name="h3" value="Books">Books <br><input type="checkbox" name="h4" value="Computers">Computers <input type="checkbox" name="h5" value="TV">TV <br>Others (<i>Please Specify</i>): <input type="text" name="h6">
?>
</td>
</tr>
<tr><td>Favourite Movie: </td><td><textarea name="favmovie"></textarea></td></tr>
<tr><td>Favourite Celebrity: </td><td><textarea name="favcelebrity"></textarea></td></tr>
<tr><td>Favourite Music: </td><td><textarea name="favmusic"></textarea></td></tr>
<tr><td>Favourite Singer: </td><td><textarea name="favsinger"></textarea></td></tr>
<tr><td>My Best Friend(s): </td><td><textarea name="bestfrnd"></textarea></td></tr>
<tr><td><input type="submit" value="Save"></td><td><input type="reset"></td></tr>
</table>
</form>
</center>
</body>
</html>