<?php
include("session.php");
include("mysqlconnect.php");
?>
<html>
<head><title>Send Message</title>
<?php
include("head.php");
?>
</head>
<body>
<?php
include("mainlinks.php");
?>
<center>
<table>
<caption><h3><i>Message</i></h3></caption>
<?php
echo "<tr><form action=sendmessagesubmit.php method=post><td>To: </td><td><input type=text name=msgto value=".$_REQUEST['fid']."></td></tr><tr><td>Text: </td><td><textarea name=msgtext rows=10 columns=100></textarea></td></tr>";
echo "<tr><td><input type=submit value=Send></td></form><form action=friends.php><td><input type=submit value=Cancel></td></form></tr>";
?>
</table>
</center>
</body>
</html>