<?php 
include("session.php");
include("mysqlconnect.php");
?>
<html>
<head>
<title>My Adda</title>
<?php
include("head.php"); 
?>
<script src="include/jquery.js"></script>
<script>
function loadMessageBox(op)
{
	document.getElementById('message_box').innerHTML="<br><br><h2 style=\"color:#0066CC;\">Loading ...</h2>";
	$(document).ready(
	function()
	{
		$("#message_box").load("messagebox.php","op="+op);
	}
	);
}

function composeMessage()
{
$(document).ready(
function()
{
document.getElementById('compose_status').innerHTML="<font color=#0066CC>Sending.....</font>";
$.post("sendmessagesubmit2.php","msgto="+document.getElementById('msgto').value+"&msgtext="+document.getElementById('msgtext').value,
function(data,status)
{
document.getElementById('compose_status').innerHTML=data;
}
);
}
);
}
</script>
<style>
button
{
	opacity:0.8;
}
button:hover
{
	opacity:1;
}
</style>
</head>
<body>
<div id="wrap">
<?php include("mainlinks.php");?>
<div id="content" style="background-position:0px 60px;background-repeat:no-repeat;background-attachment:fixed;background-image:url(images/msg.jpg);min-height:739;width:100%;">
<center>
<br><br>
<h1 style="font-weight:normal;color:#c40e0e">:: <font color="#000000">....</font> <font color="#1a0f80"><b>My Messages</b></font> <font color="#000000">....</font> ::</h1>
<center>
<table >
<tr><td style="padding:5px 80px;"><button onClick="loadMessageBox('Compose')" style=" background-color:#e9e9e9;color:#373737;font-size:15px;height:35px;border-radius:10px;width:200px;"><b>COMPOSE</b></button></td>
<td style="padding:5px 80px;"><button onClick="loadMessageBox('Inbox')" style=" background-color:#e9e9e9;color:#373737;font-size:15px;height:35px;border-radius:10px;width:200px;"><b>INBOX</b></button></td>
<td style="padding:5px 80px;"><button onClick="loadMessageBox('Sent')" style=" background-color:#e9e9e9;color:#373737;font-size:15px;height:35px;border-radius:10px;width:200px;"><b>SENT</b></button></td></tr>
</table>

<div id="message_box" height="80%" width="80%" style="border-width:0px;">
<script>loadMessageBox('Inbox');</script>
</div>
</div>

</div>
</center>
</body>
</html>