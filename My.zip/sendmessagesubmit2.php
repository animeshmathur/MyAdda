<?php 
include("session.php");
include("mysqlconnect.php");
$msgto=$_REQUEST['msgto'];
$msg=$_REQUEST['msgtext'];
$res=mysql_query("select * from autogen");
if($row=mysql_fetch_array($res))
{
	$msg=str_replace("'","''",$msg);
	$msg=str_replace("<","&lt;",$msg);
	$msg=str_replace(">","&gt;",$msg);
	$breaks = array("\r\n", "\n", "\r");
	$msg=str_replace($breaks,"<br>",$msg);
	$q="insert into messages values('".$uid."','".$msgto."','".$msg."',NOW(),'".$row['msgid']."')";
	//echo $q;
	$res1=mysql_query($q);
	if($res1)
	{
		$res2=mysql_query("update autogen set msgid=msgid+1");
		echo "<font color=green>Message Composed!</font>";
	}
	else
	{
		echo "<font color=#FF0000>Error occurred while composing!</font>";
	}
}
else
{
	echo "<font color=#FF0000>Error occurred while composing!</font>";
}
?>