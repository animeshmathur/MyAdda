<?php
include("session.php");
include("mysqlconnect.php");
?>
<html>
<head>
<title>MyAdda : FRIENDS</title>
<?php
include("head.php");
?>
<script>
function acceptFriendRequest(reqfrom)
{
$(document).ready(
function()
{
document.getElementById('friend_request_action_'+reqfrom).innerHTML="Please Wait...";
$.post("friendrequestaction.php","actiontype=accept&reqid="+reqfrom,
function(data,status)
{
document.getElementById('friend_request_action_'+reqfrom).innerHTML=data;
}
);
}
);
}

function rejectFriendRequest(reqfrom)
{
$(document).ready(
function()
{
document.getElementById('friend_request_action_'+reqfrom).innerHTML="Please Wait...";
$.post("friendrequestaction.php","actiontype=reject&reqid="+reqfrom,
function(data,status)
{
document.getElementById('friend_request_action_'+reqfrom).innerHTML=data;
}
);
}
);
}
</script>
</head>
<body>
<div id="wrap">
<?php include("mainlinks.php")?>
<div id="content">
<center>
<br><br>
<table border=0 cellpadding=20 style="text-align:center;">
<caption><h2><i>Friend Request(s)</i></h2></caption>
<?php
$res=mysql_query("select * from friends where reqto='".$uid."' and status='pending'");
if(mysql_num_rows($res))
{
	while($row=mysql_fetch_array($res))
	{
		$res1=mysql_query("select * from register where uid='".$row['reqfrom']."'");
		if($row1=mysql_fetch_array($res1))
		{
			echo "<tr><td><img src=\"upload/".$row1['dp']."\" height=80px></td><td><font color=#0066CC>".$row1['uname']."</font></td><td id=\"friend_request_action_".$row['reqfrom']."\" style=\"padding-right:80px;\"><button onclick=\"acceptFriendRequest('".$row['reqfrom']."');\" style=\"width:100px;color:#FFFFFF;background-color:#006600;border-radius:10px;\">Accept</button><br><br><button onclick=\"rejectFriendRequest('".$row['reqfrom']."');\" style=\"width:100px;color:#FFFFFF;background-color:#4D4C4C;border-radius:10px;\">Reject</button></td></tr>";	
		}
	}
}

?>
</table>
</center>
</div>
</div>
</body>
</html>