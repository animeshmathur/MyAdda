<?php
include("session.php");
include("mysqlconnect.php");
$albumid=$_REQUEST['albumid'];
$res=mysql_query("delete from albums where albumid='".$albumid."'");
header("location:albums.php");
?>