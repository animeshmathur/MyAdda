<?php
include("session.php");
include("mysqlconnect.php");
$msgid=$_REQUEST['msgid'];
$op=$_REQUEST['op'];
switch($op)
{
	case 'reply':
	$res=mysql_query("select * from messages where msgid='".$msgid."'");
	if($row=mysql_fetch_array($res))
	{
		echo "<html><head><title>Messages : Reply</title></head><body><center><table><caption><h3><i>Reply</i></h3></caption><tr><form action=messageoperation.php method=post><td>To: </td><td><input type=text name=msgto value=".$row['msgfrom']."></td></tr><tr><td>Text: </td><td><textarea name=msgtext rows=10 columns=100></textarea></td></tr>";
		echo "<tr><td><input type=hidden name=op value=replysubmit><input type=submit value=Send></td></form><form action=messagebox.php><input type=hidden name=op value=Inbox><td><input type=submit value=Cancel></td></form></tr></table></center></body></html>";
	}
	break;
	
	case 'delete':
	$res=mysql_query("delete from messages where msgid='".$msgid."'");
	header("location:messages.php");
	break;
	
	case'replysubmit':
	$msgto=$_REQUEST['msgto'];
	$msg=$_REQUEST['msgtext'];
	$res=mysql_query("select * from autogen");
	if($row=mysql_fetch_array($res))
	{
		$q="insert into messages values('".$uid."','".$msgto."','".$msg."',NOW(),'".$row['msgid']."')";
		//echo $q;
		$res1=mysql_query($q);
		if($res1)
		{
			$res2=mysql_query("update autogen set msgid=msgid+1");
		}
	}
	header("location:messages.php");
	break;
}
?>
