<?php
include("session.php");
include("mysqlconnect.php");
$reqid=$_POST['reqid'];
$actiontype=$_POST['actiontype'];
if($actiontype=='accept')
{
	$q="update friends set status='accepted' where reqto='".$uid."' and reqfrom='".$reqid."'";
	echo "<font color=#006600>(<i>Friend</i>)</font>";
}
else if($actiontype=='reject')
{
	$q="delete from friends where reqto='".$uid."' and reqfrom='".$reqid."' and status='pending'";
	echo "<font color=#FFAAAA>(<i>Rejected</i>)</font>";
}
$res=mysql_query($q);
?>
